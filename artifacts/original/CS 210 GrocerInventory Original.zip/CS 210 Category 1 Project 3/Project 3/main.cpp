// Tyler Cornwell
// CS 210 Programming Languages
// Project 3
// 8/16/2024

#include <iostream>
#include <string>
#include <fstream>
#include <map>


class Item{
public:
	void ItemSearch(std::string itemName, std::ifstream& inFS);
	void PrintList(std::ifstream& inFS);
	void PrintHistogram(std::ifstream& inFS);
	void CreateBackupFile(std::ifstream& inFS);
};

void Item::ItemSearch(std::string itemName, std::ifstream& inFS) {
	int count = 0;
	std::string currWord;

	// Clears errors
	inFS.clear();
	// Returns to the beginning of the file
	inFS.seekg(0);

	while (!inFS.eof()) {
		if (!inFS.fail()) {
			inFS >> currWord;
			if (currWord == itemName) {
				count++;
			}
		}
	}
	std::cout << std::endl;
	std::cout << itemName << " " << count << std::endl;
	std::cout << std::endl;
}

void Item::PrintList(std::ifstream& inFS) {
	std::map<std::string, int> wordCount;
	std::string currWord;

	// Clears Errors
	inFS.clear();
	// Returns to the beginning of the file
	inFS.seekg(0);

	// Reads through the file and counts the occurences of each word
	while (inFS >> currWord) {
		wordCount[currWord]++;
	}

	// Prints each word and count
	for (const auto& pair : wordCount) {
		std::cout << pair.first << " " << pair.second << std::endl;
	}
	std::cout << std::endl;
}

void Item::PrintHistogram(std::ifstream& inFS) {
	std::map<std::string, int> wordCount;
	std::string currWord;

	// Clears Errors
	inFS.clear();
	// Returns to the beginning of the file
	inFS.seekg(0);

	// Reads through the file and counts the occurences of each word
	while (inFS >> currWord) {
		wordCount[currWord]++;
	}

	for (const auto& pair : wordCount) {
		std::cout << pair.first << " ";
		for (int i = 0; i < pair.second; ++i) {
			std::cout << "*";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

void Item::CreateBackupFile(std::ifstream& inFS) {
	std::map<std::string, int> wordCount;
	std::string currWord;

	// Clears Errors
	inFS.clear();
	// Returns to the beginning of the file
	inFS.seekg(0);

	// Reads through the file and counts the occurences of each word
	while (inFS >> currWord) {
		wordCount[currWord]++;
	}

	std::ofstream outFS("frequency.dat");
	// Checks to make sure file was created
	if (!outFS.is_open()) {
		std::cout << "Could not create backup file" << std::endl;
		return;
	}

	for (const auto& pair : wordCount) {
		outFS << pair.first << " " << pair.second << std::endl;
	}

	outFS.close();
}

// Prints menu and gets user input for menu selection
void menu(std::ifstream& inFS){
	int option = 0;
	std::string userItem;
	Item item;

	while (option != 4) {
		std::cout << "Corner Grocer Inventory" << std::endl;
		std::cout << "1. Item Search" << std::endl;
		std::cout << "2. Print List of Items" << std::endl;
		std::cout << "3. Print Histogram" << std::endl;
		std::cout << "4. Quit" << std::endl;
		std::cout << std::endl;
		std::cout << "Please make a selection" << std::endl;
		std::cin >> option;
		std::cout << std::endl;

		if (option == 1) {
			std::cout << "Please enter an item to search" << std::endl;
			std::cin >> userItem;
			item.ItemSearch(userItem, inFS);
		}
		else if (option == 2) {
			item.PrintList(inFS);
		}
		else if (option == 3) {
			item.PrintHistogram(inFS);
		}
	}
}


int main() {
	std::ifstream inFS;		// Input file stream
	Item item;

	inFS.open("CS210_Project_Three_Input_File.txt");	// Opens file for reading
	// Checks to make sure file opened correctly
	if (!inFS.is_open()) {
		std::cout << "Could not open file" << std::endl;
		return 1;
	}

	menu(inFS);

	item.CreateBackupFile(inFS);
	
	
	return 0;
}