package main;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	// Use a hashmap to store the contacts with a unique ID
	private Map<String, Contact> contacts;
	
	// Constructor
	public ContactService(){
		this.contacts = new HashMap<>();
	}
	
	// Add a new contact
	public boolean addContact(Contact contact) {
		if (contacts.containsKey(contact.getId())) {
			// If the ID exists, return false
			return false;
		}
		contacts.put(contact.getId(), contact);
		return true;
	}
	
	// Delete a contact by ID
	public boolean deleteContact(String id) {
		if (!contacts.containsKey(id)) {
			// If ID doesn't exist, return false
			return false;
		}
		contacts.remove(id);
		return true;
	}
	
	// Update contact fields by ID
	public boolean updateContact(String id, String firstName, String lastName, String phone, String address) {
		Contact contact = contacts.get(id);
		if (contact == null) {
			return false;
		}
		
		// Update only non-null and valid fields
		if (firstName != null && firstName.length() <= 10) {
			contact = new Contact(contact.getId(), firstName, contact.getLastName(), contact.getPhone(), contact.getAddress());
		}
		if (lastName != null && lastName.length() <= 10) {
            contact = new Contact(contact.getId(), contact.getFirstName(), lastName, contact.getPhone(), contact.getAddress());
        }
        if (phone != null && phone.length() <= 10) {
            contact = new Contact(contact.getId(), contact.getFirstName(), contact.getLastName(), phone, contact.getAddress());
        }
        if (address != null && address.length() <= 30) {
            contact = new Contact(contact.getId(), contact.getFirstName(), contact.getLastName(), contact.getPhone(), address);
        }

        // Replace the old contact with the updated one
        contacts.put(id, contact);
        return true;
	}
	
	// Retrieve a contact by id
	public Contact getContact(String id) {
		return contacts.get(id);
	}
}
