package test;
import main.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    void setUp() {
        // Initialize a new ContactService before each test
        contactService = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact("12345", "Tyler", "Cornwell", "1234567890", "123 Main Street");
        assertTrue(contactService.addContact(contact)); // Should return true for successful addition
        assertNotNull(contactService.getContact("12345")); // Verify the contact is stored
    }

    @Test
    void testAddContactDuplicateId() {
        Contact contact1 = new Contact("12345", "Tyler", "Cornwell", "1234567890", "123 Main Street");
        Contact contact2 = new Contact("12345", "Sam", "Cornwell", "0987654321", "456 Another St");

        contactService.addContact(contact1);
        assertFalse(contactService.addContact(contact2)); // Should return false for duplicate ID
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("12345", "Tyler", "Cornwell", "1234567890", "123 Main Street");
        contactService.addContact(contact);

        assertTrue(contactService.deleteContact("12345")); // Should return true for successful deletion
        assertNull(contactService.getContact("12345")); // Verify the contact is removed
    }

    @Test
    void testDeleteContactNonexistentId() {
        assertFalse(contactService.deleteContact("99999")); // Should return false for non-existent ID
    }

    @Test
    void testUpdateContactFields() {
        Contact contact = new Contact("12345", "Tyler", "Cornwell", "1234567890", "123 Main Street");
        contactService.addContact(contact);

        // Update fields
        assertTrue(contactService.updateContact("12345", "Sam", null, "0987654321", "456 Another St"));

        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Sam", updatedContact.getFirstName()); // Verify first name is updated
        assertEquals("Cornwell", updatedContact.getLastName()); // Last name should remain unchanged
        assertEquals("0987654321", updatedContact.getPhone()); // Verify phone is updated
        assertEquals("456 Another St", updatedContact.getAddress()); // Verify address is updated
    }

    @Test
    void testUpdateContactNonexistentId() {
        assertFalse(contactService.updateContact("99999", "Johnny", null, "0987654321", "456 Another St"));
    }

    @Test
    void testUpdateContactInvalidFields() {
        Contact contact = new Contact("12345", "Tyler", "Cornwell", "1234567890", "123 Main Street");
        contactService.addContact(contact);

        // Attempt to update with invalid values
        assertTrue(contactService.updateContact("12345", "Namethatiswaytoolong", null, "0987654321IsWayTooLong", "456 Another St"));

        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Tyler", updatedContact.getFirstName()); // First name should remain unchanged
        assertEquals("1234567890", updatedContact.getPhone()); // Phone should remain unchanged
    }
}
