/*
Tyler Cornwell
12/9/2024
CS 300 Data Structures and Algorithms
Project Two
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cctype>

// Structure to represent a course with its details
struct Course {
    std::string courseNumber;
    std::string name;
    std::vector<std::string> prerequisites;
};

// Global hash table to store course data, indexed by course number
std::unordered_map<std::string, Course> courses;

// Load courses from the CSV file
void loadCourses() {
    const std::string fileName = "CS 300 ABCU_Advising_Program_Input.csv";
    std::ifstream file(fileName);

    // Check if the file could be opened
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open file \"" << fileName << "\"." << std::endl;
        return;
    }

    std::string line;
    // Read each line of the CSV file
    while (std::getline(file, line)) {
        std::istringstream stream(line);
        std::string courseNumber, name, prereq;

        // Parse course number and name from the line
        std::getline(stream, courseNumber, ',');
        std::getline(stream, name, ',');

        Course course;
        course.courseNumber = courseNumber;
        course.name = name;

        // Parse and store all prerequisites
        while (std::getline(stream, prereq, ',')) {
            course.prerequisites.push_back(prereq);
        }

        // Add the course to the hash table
        courses[courseNumber] = course;
    }

    file.close(); // Close the file after reading
    std::cout << "Courses successfully loaded from file." << std::endl;
}

// Print a sorted list of all courses
void printCourseList() {
    std::vector<std::string> sortedKeys;
    for (const auto& pair : courses) {
        sortedKeys.push_back(pair.first);
    }
    std::sort(sortedKeys.begin(), sortedKeys.end());

    std::cout << "Here is a sample schedule:" << std::endl;
    for (const std::string& key : sortedKeys) {
        const Course& course = courses[key];
        std::cout << course.courseNumber << ", " << course.name << std::endl;
    }
}

// Print details of a specific course
void printCourseDetails(const std::string& courseNumber) {
    auto it = courses.find(courseNumber);
    if (it == courses.end()) {
        std::cout << "Course not found." << std::endl;
        return;
    }

    const Course& course = it->second;
    std::cout << course.courseNumber << ", " << course.name << std::endl;
    std::cout << "Prerequisites: ";
    for (size_t i = 0; i < course.prerequisites.size(); ++i) {
        std::cout << course.prerequisites[i];
        if (i < course.prerequisites.size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << std::endl;
}

// Convert a string to uppercase
std::string toUpperCase(const std::string& str) {
    std::string result;
    for (char c : str) {
        result += std::toupper(c);
    }
    return result;
}

// Display program menu
void displayMenu() {
    std::cout << "Welcome to the course planner." << std::endl;
    std::cout << "1. Load Data Structure." << std::endl;
    std::cout << "2. Print Course List." << std::endl;
    std::cout << "3. Print Course." << std::endl;
    std::cout << "9. Exit" << std::endl;
}

int main() {
    int choice;

    do {
        displayMenu();
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            loadCourses();
            break;
        case 2:
            if (courses.empty()) {
                // Check if courses have been loaded
                std::cout << "No course data loaded. Please load data first." << std::endl;
            }
            else {
                printCourseList();
            }
            break;
        case 3:
            if (courses.empty()) {
                // Check if courses have been loaded
                std::cout << "No course data loaded. Please load data first." << std::endl;
            }
            else {
                std::cout << "What course do you want to know about? ";
                std::string courseNumber;
                std::cin >> courseNumber;
                printCourseDetails(toUpperCase(courseNumber));
            }
            break;
        case 9:
            std::cout << "Thank you for using the course planner!" << std::endl;
            break;
        default:
            // Handles invalid menu options
            std::cout << choice << " is not a valid option." << std::endl;
        }
    } while (choice != 9); // Loops until user chooses 9 to exit

    return 0;
}