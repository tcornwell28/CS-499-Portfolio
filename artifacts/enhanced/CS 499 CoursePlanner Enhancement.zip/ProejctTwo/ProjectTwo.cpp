/*
Tyler Cornwell
12/9/2024
CS 300 Data Structures and Algorithms
Project Two
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cctype>
#include <set>


// Class to represent a course
class Course {
public:
    std::string courseNumber;
    std::string name;
    std::vector<std::string> prerequisites;
};

// Class to manage the course planner logic
class CoursePlanner {
private:
    std::unordered_map<std::string, Course> courses;

    // Helper method to recursively detect circular dependencies
    bool hasCircularDependency(const std::string& courseNumber, std::set<std::string>& visited) {
        if (visited.count(courseNumber)) {
            std::cout << "Circular dependency detected at course: " << courseNumber << std::endl;
            return true;
        }
        visited.insert(courseNumber);

        for (const std::string& prereq : courses[courseNumber].prerequisites) {
            if (prereq.empty()) {
                continue; // skip blank cells in CSV
            }
            if (courses.find(prereq) == courses.end()) {
                std::cout << "Error: Prerequisite course not found: \"" << prereq << "\"" << std::endl;
                return true;
            }
            if (hasCircularDependency(prereq, visited)) {
                return true;
            }
        }

        visited.erase(courseNumber);
        return false;
    }

public:
    // Load courses from file into the hash map
    void loadCourses() {
        const std::string fileName = "CS 300 ABCU_Advising_Program_Input.csv";
        std::ifstream file(fileName);

        if (!file.is_open()) {
            std::cerr << "Error: Unable to open file \"" << fileName << "\"." << std::endl;
            return;
        }

        std::string line;
        while (std::getline(file, line)) {
            std::istringstream stream(line);
            std::string courseNumber, name, prereq;

            std::getline(stream, courseNumber, ',');
            std::getline(stream, name, ',');

            Course course;
            course.courseNumber = courseNumber;
            course.name = name;

            while (std::getline(stream, prereq, ',')) {
                course.prerequisites.push_back(prereq);
            }

            courses[courseNumber] = course;
        }

        file.close();
        std::cout << "Courses successfully loaded from file." << std::endl;
    }

    // Print a sorted list of courses
    void printCourseList() const {
        std::vector<std::string> sortedKeys;
        for (const auto& pair : courses) {
            sortedKeys.push_back(pair.first);
        }
        std::sort(sortedKeys.begin(), sortedKeys.end());

        std::cout << "Here is a sample schedule:" << std::endl;
        for (const std::string& key : sortedKeys) {
            const Course& course = courses.at(key);
            std::cout << course.courseNumber << ", " << course.name << std::endl;
        }
    }

    // Print details of a specific course
    void printCourseDetails(const std::string& courseNumber) const {
        auto it = courses.find(courseNumber);
        if (it == courses.end()) {
            std::cout << "Course not found." << std::endl;
            return;
        }

        const Course& course = it->second;
        std::cout << course.courseNumber << ", " << course.name << std::endl;
        std::cout << "Prerequisites: ";
        for (size_t i = 0; i < course.prerequisites.size(); ++i) {
            std::cout << course.prerequisites[i];
            if (i < course.prerequisites.size() - 1) {
                std::cout << ", ";
            }
        }
        std::cout << std::endl;
    }

    // Run validation for circular dependencies
    void validatePrerequisites() {
        bool issuesFound = false;

        for (const auto& pair : courses) {
            std::set<std::string> visited;
            if (hasCircularDependency(pair.first, visited)) {
                std::cout << "Circular prerequisite found starting from " << pair.first << std::endl;
                issuesFound = true;
            }
        }

        if (issuesFound) {
            std::cout << "Validation completed with issues.\n" << std::endl;
        }
        else {
            std::cout << "No missing or circular prerequisites detected.\nValidation completed successfully.\n" << std::endl;
        }
    }

    // Helper function to check if data is loaded
    bool isLoaded() const {
        return !courses.empty();
    }

    // Convert a string to uppercase
    static std::string toUpperCase(const std::string& str) {
        std::string result;
        for (char c : str) {
            result += std::toupper(c);
        }
        return result;
    }
};

// Display menu options
void displayMenu() {
    std::cout << "Welcome to the course planner." << std::endl;
    std::cout << "1. Load Data Structure." << std::endl;
    std::cout << "2. Print Course List." << std::endl;
    std::cout << "3. Print Course." << std::endl;
    std::cout << "4. Validate Prerequisites." << std::endl;
    std::cout << "9. Exit" << std::endl;
}

int main() {
    int choice;
    CoursePlanner planner;

    do {
        displayMenu();
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            planner.loadCourses();
            break;
        case 2:
            if (!planner.isLoaded()) {
                std::cout << "No course data loaded. Please load data first." << std::endl;
            }
            else {
                planner.printCourseList();
            }
            break;
        case 3:
            if (!planner.isLoaded()) {
                std::cout << "No course data loaded. Please load data first." << std::endl;
            }
            else {
                std::cout << "What course do you want to know about? ";
                std::string courseNumber;
                std::cin >> courseNumber;
                planner.printCourseDetails(CoursePlanner::toUpperCase(courseNumber));
            }
            break;
        case 4:
            if (!planner.isLoaded()) {
                std::cout << "No course data loaded. Please load data first." << std::endl;
            }
            else {
                planner.validatePrerequisites();
            }
            break;
        case 9:
            std::cout << "Thank you for using the course planner!" << std::endl;
            break;
        default:
            std::cout << choice << " is not a valid option." << std::endl;
        }
    } while (choice != 9);

    return 0;
}
