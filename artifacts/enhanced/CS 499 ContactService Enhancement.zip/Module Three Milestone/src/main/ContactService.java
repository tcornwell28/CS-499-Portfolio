package main;

import java.sql.*;

public class ContactService {

    public boolean addContact(Contact contact) {
        if (getContact(contact.getId()) != null) {
            //System.out.println("Contact with ID " + contact.getId() + " already exists.");
            return false;
        }

        String sql = "INSERT INTO contacts (id, first_name, last_name, phone, address) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, contact.getId());
            stmt.setString(2, contact.getFirstName());
            stmt.setString(3, contact.getLastName());
            stmt.setString(4, contact.getPhone());
            stmt.setString(5, contact.getAddress());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteContact(String id) {
        String sql = "DELETE FROM contacts WHERE id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateContact(String id, String firstName, String lastName, String phone, String address) {
        Contact existing = getContact(id);
        if (existing == null) return false;

        // Validate inputs (null = no change, but if provided, must be valid)
        if ((firstName != null && firstName.length() > 10) ||
            (lastName != null && lastName.length() > 10) ||
            (phone != null && phone.length() != 10) ||
            (address != null && address.length() > 30)) {
            return false; // Invalid input
        }

        // Use new values if valid, otherwise keep existing
        String updatedFirstName = (firstName != null) ? firstName : existing.getFirstName();
        String updatedLastName = (lastName != null) ? lastName : existing.getLastName();
        String updatedPhone = (phone != null) ? phone : existing.getPhone();
        String updatedAddress = (address != null) ? address : existing.getAddress();

        String sql = "UPDATE contacts SET first_name = ?, last_name = ?, phone = ?, address = ? WHERE id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, updatedFirstName);
            stmt.setString(2, updatedLastName);
            stmt.setString(3, updatedPhone);
            stmt.setString(4, updatedAddress);
            stmt.setString(5, id);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Contact getContact(String id) {
        String sql = "SELECT * FROM contacts WHERE id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Contact(
                        rs.getString("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("phone"),
                        rs.getString("address")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}