package test;
import main.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {
		Contact Contact = new Contact("12345", "Tyler", "Cornwell", "1234567890", "123 Main Drive");
		assertTrue(Contact.getId().equals("12345"));
		assertTrue(Contact.getFirstName().equals("Tyler"));
		assertTrue(Contact.getLastName().equals("Cornwell"));
		assertTrue(Contact.getPhone().equals("1234567890"));
		assertTrue(Contact.getAddress().equals("123 Main Drive"));
	}
	
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", "Cornwell", "1234567", "123 Main Drive");
		});
	}
	
	@Test
	void testContactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Tyler", "Cornwell", "1234567", "123 Main Drive");
		});
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tylerabcdefg", "Cornwell", "1234567", "123 Main Drive");
		});
	}
	
	@Test
	void testContactFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", null, "Cornwell", "1234567", "123 Main Drive");
		});
	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", "Cornwellabc", "1234567", "123 Main Drive");
		});
	}
	
	@Test
	void testContactLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", null, "1234567", "123 Main Drive");
		});
	}
	
	@Test
	void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", "Cornwell", "1234567891011", "123 Main Drive");
		});
	}
	
	@Test
	void testContactPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1234567890", "Tyler", "Cornwell", "12345", "123 Main Drive");
		});
	}
	
	@Test
	void testContactPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", "Cornwell", null, "123 Main Drive");
		});
	}
	
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", "Cornwell", "1234567", "12312585214526874584584554 Main Drive");
		});
	}
	
	@Test
	void testContactAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Tyler", "Cornwell", "1234567", null);
		});
	}

}
