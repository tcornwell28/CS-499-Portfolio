package test;
import main.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    void setUp() throws SQLException {
        contactService = new ContactService();

        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute("DELETE FROM contacts"); // Clear all entries before each test
        }
    }

    @Test
    void testAddContact() {
    	String id = "test" + System.currentTimeMillis();
        Contact contact = new Contact(id, "Tyler", "Cornwell", "1234567890", "123 Main Street");
        assertTrue(contactService.addContact(contact)); // Should return true for successful addition
        assertNotNull(contactService.getContact(id)); // Verify the contact is stored
    }

    @Test
    void testAddContactDuplicateId() {
    	String id = "test" + System.currentTimeMillis();
        Contact contact1 = new Contact(id, "Tyler", "Cornwell", "1234567890", "123 Main Street");
        Contact contact2 = new Contact(id, "Sam", "Cornwell", "0987654321", "456 Another St");

        contactService.addContact(contact1);
        assertFalse(contactService.addContact(contact2)); // Should return false for duplicate ID
    }

    @Test
    void testDeleteContact() {
    	String id = "test" + System.currentTimeMillis();
        Contact contact = new Contact(id, "Tyler", "Cornwell", "1234567890", "123 Main Street");
        contactService.addContact(contact);

        assertTrue(contactService.deleteContact(id)); // Should return true for successful deletion
        assertNull(contactService.getContact(id)); // Verify the contact is removed
    }

    @Test
    void testDeleteContactNonexistentId() {
        assertFalse(contactService.deleteContact("99999")); // Should return false for non-existent ID
    }

    @Test
    void testUpdateContactFields() {
    	String id = "test" + System.currentTimeMillis();
        Contact contact = new Contact(id, "Tyler", "Cornwell", "1234567890", "123 Main Street");
        contactService.addContact(contact);

        // Update fields
        assertTrue(contactService.updateContact(id, "Sam", null, "0987654321", "456 Another St"));

        Contact updatedContact = contactService.getContact(id);
        assertEquals("Sam", updatedContact.getFirstName()); // Verify first name is updated
        assertEquals("Cornwell", updatedContact.getLastName()); // Last name should remain unchanged
        assertEquals("0987654321", updatedContact.getPhone()); // Verify phone is updated
        assertEquals("456 Another St", updatedContact.getAddress()); // Verify address is updated
    }

    @Test
    void testUpdateContactNonexistentId() {
        assertFalse(contactService.updateContact("99999", "Johnny", null, "0987654321", "456 Another St"));
    }

    @Test
    void testUpdateContactInvalidFields() {
    	String id = "test" + System.currentTimeMillis();
        Contact contact = new Contact(id, "Tyler", "Cornwell", "1234567890", "123 Main Street");
        contactService.addContact(contact);

        // Attempt to update with invalid values
        assertFalse(contactService.updateContact(id, "Namethatiswaytoolong", null, "0987654321IsWayTooLong", "456 Another St"));

        Contact updatedContact = contactService.getContact(id);
        assertEquals("Tyler", updatedContact.getFirstName()); // First name should remain unchanged
        assertEquals("1234567890", updatedContact.getPhone()); // Phone should remain unchanged
    }
}
