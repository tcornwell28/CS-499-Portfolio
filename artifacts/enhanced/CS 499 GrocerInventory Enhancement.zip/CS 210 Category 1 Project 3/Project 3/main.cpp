// Tyler Cornwell
// CS 499
// Enhancement 1

#include <iostream>
#include <string>
#include <fstream>
#include <map>

class Item {
private:
    std::map<std::string, int> inventory; // Stores word frequencies from the input file

public:
    // Loads inventory from a file into the map
    bool LoadInventory(const std::string& filename);

    // Searches for a specific item and prints its count
    void ItemSearch(const std::string& itemName);

    // Prints the list of items and their counts
    void PrintList();

    // Prints a histogram of item frequencies
    void PrintHistogram();

    // Creates a backup file with the current inventory
    void CreateBackupFile(const std::string& filename);
};

bool Item::LoadInventory(const std::string& filename) {
    std::ifstream inFS(filename); // Input file stream
    std::string currWord;

    // Clear current inventory before loading new one
    inventory.clear();

    // Check if file opens successfully
    if (!inFS.is_open()) {
        std::cout << "Could not open file: " << filename << std::endl;
        return false;
    }

    // Read words and count frequencies
    while (inFS >> currWord) {
        inventory[currWord]++;
    }

    inFS.close();
    std::cout << "File loaded successfully.\n" << std::endl;
    return true;
}

void Item::ItemSearch(const std::string& itemName) {
    std::cout << std::endl;
    std::cout << itemName << " " << inventory[itemName] << std::endl;
    std::cout << std::endl;
}

void Item::PrintList() {
    std::cout << "\nItem List:\n" << std::endl;
    for (const auto& pair : inventory) {
        std::cout << pair.first << " " << pair.second << std::endl;
    }
    std::cout << std::endl;
}

void Item::PrintHistogram() {
    std::cout << "\nHistogram:\n" << std::endl;
    for (const auto& pair : inventory) {
        std::cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            std::cout << "*";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void Item::CreateBackupFile(const std::string& filename) {
    std::ofstream outFS(filename); // Output file stream

    // Check if the file is open
    if (!outFS.is_open()) {
        std::cout << "Could not create backup file: " << filename << std::endl;
        return;
    }

    // Write inventory to file
    for (const auto& pair : inventory) {
        outFS << pair.first << " " << pair.second << std::endl;
    }

    outFS.close();
    std::cout << "Backup saved to " << filename << "\n" << std::endl;
}

// Displays the main menu options
void DisplayMenu() {
    std::cout << "Corner Grocer Inventory System" << std::endl;
    std::cout << "1. Load Inventory File" << std::endl;
    std::cout << "2. Search for Item" << std::endl;
    std::cout << "3. Print Item List" << std::endl;
    std::cout << "4. Print Histogram" << std::endl;
    std::cout << "5. Save Backup File" << std::endl;
    std::cout << "6. Exit" << std::endl;
    std::cout << "\nPlease make a selection: ";
}

// Menu function to handle user input and call corresponding item functions
void Menu() {
    int option = 0;
    std::string filename;
    std::string userItem;
    Item item;
    bool isDataLoaded = false;

    do {
        DisplayMenu();
        std::cin >> option;
        std::cin.ignore(); // Clear input buffer
        std::cout << std::endl;

        switch (option) {
        case 1:
            std::cout << "Enter file name to load: ";
            std::getline(std::cin, filename);
            isDataLoaded = item.LoadInventory(filename);
            break;

        case 2:
            if (!isDataLoaded) {
                std::cout << "No data loaded. Please load a file first.\n" << std::endl;
                break;
            }
            std::cout << "Enter item to search: ";
            std::getline(std::cin, userItem);
            item.ItemSearch(userItem);
            break;

        case 3:
            if (!isDataLoaded) {
                std::cout << "No data loaded. Please load a file first.\n" << std::endl;
                break;
            }
            item.PrintList();
            break;

        case 4:
            if (!isDataLoaded) {
                std::cout << "No data loaded. Please load a file first.\n" << std::endl;
                break;
            }
            item.PrintHistogram();
            break;

        case 5:
            if (!isDataLoaded) {
                std::cout << "No data loaded. Please load a file first.\n" << std::endl;
                break;
            }
            std::cout << "Enter filename to save backup (e.g., frequency.dat): ";
            std::getline(std::cin, filename);
            item.CreateBackupFile(filename);
            break;

        case 6:
            std::cout << "Exiting program. Goodbye!\n" << std::endl;
            break;

        default:
            std::cout << "Invalid selection. Please try again.\n" << std::endl;
        }
    } while (option != 6);
}

int main() {
    Menu(); // Start the program
    return 0;
}
